<footer>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 col-xs-12" id="copyright">
                    <p>&#169; website.com. All rights reserved.</p>
                </div>
                <div class="col-md-6" id="logo">
                    <img src={{ asset('images/footer-logo.png') }} width="130">
                </div>
            </div>
        </div>
    </footer>