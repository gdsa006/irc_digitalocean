
<?php $__env->startSection('dashboard-content'); ?>





<h2>Dashboard</h2>
<hr>
<div class="row">
<div class="col-md-6"> 
<div class="card shadow">
                <div class="card-body" style="background: deepskyblue; color: aliceblue;">
                    <h2 class="card-title">Leads</h2>
                    <p class="card-text">Some latest leads </p>
                </div>
                <div class="card-body card-p py-0">
                    <div class="row">
                        
                    <div class="table-responsive">
  <table class="table">
   
    <tbody>
      <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($lead->fname); ?></td>
          <td><?php echo e(Str::limit($lead->address, 22)); ?></td>
          <td><?php echo e($lead->sqft); ?> Sqft</td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
</div>


                    </div>
                    <div class="card-body text-center">
                <a href="/dashboard/leads/all" class="btn btn-default">View All</a>
</div>
                </div>
            </div>
</div>


<div class="col-md-6"> 
<div class="card shadow">
                <div class="card-body" style="background: salmon; color: aliceblue;">
                    <h2 class="card-title">Rates</h2>
                    <p class="card-text">Latest rates.</p>
                </div>
                <div class="card-body card-p py-0">
                    <div class="row">
                    <table class="table">
   
   <tbody>
   <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($rate->af); ?></td>
          <td><?php echo e($rate->mf); ?></td>
          <td><?php echo e($rate->of); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
 </table>
                    </div>
                </div>

<div class="card-body text-center">
                <a href="/dashboard/rates" class="btn btn-default">View All</a>
</div>

            </div>
</div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('new.dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gagan\OneDrive\Documents\JBSoft\irc_on_Lenovo\resources\views/new/dashboard/dashboard.blade.php ENDPATH**/ ?>