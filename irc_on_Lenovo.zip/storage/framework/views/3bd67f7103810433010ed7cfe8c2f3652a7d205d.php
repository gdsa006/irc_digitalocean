<!DOCTYPE html>
<html>
<head>
    <title>idahoroofingcost.com</title>
</head>
<body>
    <h3>New Lead</h3>
    <table>
        <tr>
            <td>Name: </td>
            <td><?php echo e($details['fname']); ?> <?php echo e($details['lname']); ?></td>
        </tr>
        <tr>
            <td>Mobile</td>
            <td><?php echo e($details['mobile']); ?></td>
        </tr>

        <tr>
            <td>Location</td>
            <td><?php echo e($details['address']); ?></td>
        </tr>

        <tr>
            <td>Sqft</td>
            <td><?php echo e($details['sqft']); ?></td>
        </tr>

        <tr>
            <td>Slope</td>
            <td><?php echo e($details['steep']); ?></td>
        </tr>

        <tr>
            <td>Currently</td>
            <td><?php echo e($details['existingmaterial']); ?></td>
        </tr>

        <tr>
            <td>Urgent</td>
            <td><?php echo e($details['urgency']); ?></td>
        </tr>

        <tr>
            <td>Insurance</td>
            <td><?php echo e($details['insurance']); ?></td>
        </tr>

        <tr>
            <td>Required</td>
            <td><?php echo e($details['material']); ?></td>
        </tr>

        <tr>
            <td>Interested in Financing</td>
            <td><?php echo e($details['isinterestedinfinancing']); ?></td>
        </tr>


    </table>

   
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\Users\gagan\OneDrive\Documents\JBSoft\irc_on_Lenovo\resources\views/new/dashboard/admin-mail.blade.php ENDPATH**/ ?>