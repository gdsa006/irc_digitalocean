<footer>
    <div class="container">
        <div class="row">
            <p class="">&#169; idahoroofingcost.com. All rights reserved.</p>
            <ul>
                <li><a href="/privacy-policy">Privacy</a></li>
                <li><a href="/terms-of-service">T&C</a></li>
                <li><a href="/our-guarantee">Our Guarantee</a></li>                
            </ul>
        </div>
    </div>
</footer>