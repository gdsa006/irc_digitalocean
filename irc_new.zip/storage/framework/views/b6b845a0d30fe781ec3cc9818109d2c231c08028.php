
<?php $__env->startSection('dashboard-content'); ?>

<div class="d-block mb-5">
<h2 class="float-left">Leads(Urgent)</h2>
<a class="btn btn-warning float-right" href="<?php echo e(route('export-urgent-leads')); ?>">Export Data</a>
</div>


<div class="table-responsive">
  <table class="table">
    <tbody>
    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr id="lead-<?php echo e($lead->id); ?>">
        <td><?php echo e($lead->id); ?></td>
        <td><?php echo e($lead->fname ? $lead->fname . $lead->lname : '-'); ?> </td>
        <td><?php echo e($lead->mobile ? $lead->mobile : '-'); ?></td>
        <td><?php echo e($lead->address); ?></td>
        <td><a data-html="true" href="javascript:void(0)" title="Sqft: <?php echo e($lead->sqft); ?> <br/> Roof: <?php echo e($lead->steep); ?> <br/> Currently: <?php echo e($lead->existingmaterial); ?> <br/> Required: <?php echo e($lead->material); ?> <br/> Urgent: <?php echo e($lead->urgency); ?> <br/> Insurance: <?php echo e($lead->true); ?> <br/> Interested in financing: <?php echo e($lead->isinterestedinfinancing); ?> ">Details</a></td>
        <td><a href="#" data-id="<?php echo e($lead->id); ?>" class="text-danger deleteLead" id="">Remove</a></td>
      </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td colspan="4"><?php echo e($leads->links('pagination::bootstrap-4')); ?></td>
</tr>
    </tbody>
    
  </table>
</div>








    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('new.dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u253752940/domains/idahoroofingcost.com/idahoroofingcost/resources/views/new/dashboard/leads-urgent.blade.php ENDPATH**/ ?>