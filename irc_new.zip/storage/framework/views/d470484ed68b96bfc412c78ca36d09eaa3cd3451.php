<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
  <a class="navbar-brand" href="/"><img src="<?php echo e(asset('images/Final Logo-01.png')); ?>"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="javascript:void(0)" style="cursor: default;">See how much you can save on a new roof!</a>
</li>
    </ul>
  </div>
  <a href="#" class="custom-main-btn medium ml-auto userForm">Get Estimate</a>
</div>
</nav><?php /**PATH C:\Users\gagan\OneDrive\Documents\JBSoft\irc_new\resources\views/new/header.blade.php ENDPATH**/ ?>