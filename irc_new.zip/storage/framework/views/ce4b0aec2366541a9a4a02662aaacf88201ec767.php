
<?php $__env->startSection('dashboard-content'); ?>
<form method="post" class="col-12 col-md-4 offset-md-4 " action="<?php echo e(route('login')); ?>">
<img src="<?php echo e(asset('images/Final Logo-01.png')); ?>" class="mx-auto d-block mb-5" width="200">
    <?php echo csrf_field(); ?>
  <div class="form-group">
    <label>Username</label>
    <input type="text" name="name" class="form-control p_input">
  </div>
  <div class="form-group">
    <label>Password *</label>
    <input type="password" name="password" class="form-control p_input">
  </div>

  <div class="text-center">
    <button type="submit" class="btn btn-primary btn-block enter-btn">Login</button>
  </div>

  <?php if(Session::has('message')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('new.dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u253752940/domains/idahoroofingcost.com/idahoroofingcost/resources/views/new/dashboard/login.blade.php ENDPATH**/ ?>