
<?php $__env->startSection('dashboard-content'); ?>
<h2 class="mb-3">Lead</h2>

<div class="row mb-5">
<div class="col-6">
    <h6 style="text-transform: capitalize;"><?php echo e($lead->fname); ?> <?php echo e($lead->lname); ?> </h6>
</div>
<div class="col-6">
    <h6><?php echo e($lead->email); ?></h6>
    <h6><?php echo e($lead->mobile); ?></h6>
</div>
</div>


<table class="table" style="font-size: 15px">
   
    <tbody>
      <tr>
        <td><p>Location:</td>
        <td><p><?php echo e($lead->address); ?></p></td>
      </tr>

      <tr>
        <td><p>Homes Square Footage:</p></td>
        <td><p><?php echo e($lead->sqft); ?></p></td>
      </tr>

      <tr>
        <td><p>Steep Roof:</p></td>
        <td><p><?php echo e($lead->steep); ?></p></td>
      </tr>

      <tr>
        <td><p>Currently on your Roof:</p></td>
        <td><p><?php echo e($lead->existingmaterial); ?></p></td>
      </tr>

      <tr>
        <td><p>Urgency:</p></td>
        <td><p><?php echo e($lead->urgency); ?></p></td>
      </tr>

      <tr>
        <td><p>Insurance to repair your Roof:<p></td>
        <td><p><?php echo e($lead->true); ?></p></td>
      </tr>

      <tr>
        <td><p>Liked on your Roof:</p></td>
        <td><p><?php echo e($lead->material); ?></p></td>
      </tr>

      <tr>
        <td>Interested in Financing this Project Over Time:</td>
        <td><?php echo e($lead->isinterestedinfinancing); ?></td>
      </tr>
    </tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('new.dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gagan\OneDrive\Documents\JBSoft\irc_on_Lenovo\resources\views/new/dashboard/show-lead.blade.php ENDPATH**/ ?>